package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(User user) {

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        if (user.getRole() == null) {
            user.setRole("STUDENT");
        }

        userRepository.save(user);

        return "redirect:/login";
    }
    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; // login.html
    }
    @GetMapping("/default")
    public String defaultAfterLogin(User user) {

        String role = user.getRole();
        switch(role) {
            case "STUDENT":
                return "redirect:/students/dashboard";
            case "SUPERVISOR":
                return "redirect:/supervisors/dashboard";
            case "EVALUATOR":
                return "redirect:/evaluators/dashboard";
            case "FYP_COMMITTEE":
                return "redirect:/fyp/dashboard";
            default:
                return "redirect:/login";
        }
    }
}
