package com.example.demo.controller;

import com.example.demo.model.Deadline;
import com.example.demo.model.Document;
import com.example.demo.model.FypDocumentType;
import com.example.demo.service.DeadlineService;
import com.example.demo.service.DocumentService;
import com.example.demo.service.NotificationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FypCommitteeController {

    private final DeadlineService deadlineService;
    private final DocumentService documentService;
    private final NotificationService notificationService;

    public FypCommitteeController(DeadlineService deadlineService,
                                  NotificationService notificationService, DocumentService documentService) {
        this.deadlineService = deadlineService;
        this.documentService = documentService;
        this.notificationService = notificationService;
    }

    // ---------------- Dashboard ----------------
    @GetMapping("/fyp/dashboard")
    public String fypDashboard(Model model) {
        model.addAttribute("deadlines", deadlineService.getActiveDeadlines());
        model.addAttribute("documents",documentService.getAllDocuments());
        return "fyp-dashboard";
    }

    // ---------------- Open Create Deadline Page ----------------
    @GetMapping("/deadline/create")
    public String showCreateDeadlineForm(Model model) {
        model.addAttribute("deadline", new Deadline());
        model.addAttribute("types", FypDocumentType.values());
        return "create-deadline";
    }


    @PostMapping("/fyp/create-deadline")
    public String createDeadline(@ModelAttribute Deadline deadline, Model model) {
        // 1. MUST SET ACTIVE: Taake repository query mein ye show ho
        deadline.setActive(true);

        // 2. Save deadline
        deadlineService.createDeadline(deadline);

        // 3. Notify all students
        notificationService.notifyAllStudents(
                "New deadline added: " + deadline.getTitle() +
                        " due on " + deadline.getDueDate()
        );

        return "redirect:/fyp/dashboard";
    }

    @PostMapping("/fyp/document/{id}/finalize")
    public String finalizeDocument(@PathVariable Long id) {
        documentService.finalizeResult(id);
        return "redirect:/fyp/dashboard";
    }
    @PostMapping("/fyp/release-result/{id}")
    public String releaseFinalResult(@PathVariable Long id) {

        Document doc = documentService.getDocumentById(id);

        if (doc != null) {
            doc.setStatus("FINALIZED");
            documentService.save(doc);

            notificationService.sendNotification(
                    doc.getStudent().getId(),
                    "🎓 Final result released for document '" +
                            doc.getTitle() +
                            "'. Final Grade: " + doc.getGrade()
            );
        }

        return "redirect:/fyp/dashboard";
    }
}
