package com.example.demo.model;

public enum FypDocumentType {   // <-- rename
    PROPOSAL,
    DESIGN,
    TEST,
    THESIS
}
