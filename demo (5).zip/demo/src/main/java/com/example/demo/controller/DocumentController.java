package com.example.demo.controller;

import com.example.demo.model.Deadline;
import com.example.demo.model.Document;
import com.example.demo.model.FypDocumentType;
import com.example.demo.repository.DeadlineRepository;
import com.example.demo.service.DeadlineService;
import com.example.demo.service.DocumentService;
import com.example.demo.service.UserService;

import org.springframework.core.io.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;


import com.example.demo.model.Document;
import com.example.demo.service.DocumentService;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
@Controller
@RequestMapping("/documents")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    private final DeadlineRepository deadlineRepository;

    @Autowired
    public DocumentController(DeadlineRepository deadlineRepository) {
        this.deadlineRepository = deadlineRepository;
    }
    @Autowired
    private DeadlineService deadlineService;

    @Autowired
    private UserService userService;

    @GetMapping("/upload")
    public String showUploadForm(Model model) {
        Long studentId = userService.getLoggedInStudentId();
        if (studentId == null) return "redirect:/login";

        // 1. Sirf wahi deadlines layein jo ACTIVE hain (is_active = 1)
        List<Deadline> activeDeadlines = deadlineService.getActiveDeadlines();

        // Debugging: Console check karein ke data aa raha hai ya nahi
        System.out.println("Active Deadlines Found: " + activeDeadlines.size());

        model.addAttribute("deadlines", activeDeadlines); // Iska naam 'deadlines' hona chahiye
        model.addAttribute("supervisors", userService.getAllSupervisors());
        model.addAttribute("document", new Document());

        return "upload-document";
    }

    @GetMapping("/documents/download/{id}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long id) {
        try {
            Document doc = documentService.getDocumentById(id);
            if (doc == null || doc.getFilePath() == null) {
                return ResponseEntity.notFound().build();
            }

            Path path = Paths.get(doc.getFilePath());
            Resource resource = new UrlResource(path.toUri());

            if (resource.exists() || resource.isReadable()) {
                // 1. File path se extension (.pdf, .docx etc) nikalne ki logic
                String filePath = doc.getFilePath();
                String extension = "";
                int i = filePath.lastIndexOf('.');
                if (i > 0) {
                    extension = filePath.substring(i);
                }

                // 2. Title ke saath extension jorein taake file sahi open ho
                String finalFileName = doc.getTitle() + extension;

                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + finalFileName + "\"")
                        .header(HttpHeaders.CONTENT_TYPE, "application/octet-stream")
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
    
    
    // ---------------- Handle File Upload ----------------
    @PostMapping("/upload")
    public String uploadDocument(
            @RequestParam String title,
            @RequestParam String type,
            @RequestParam Long supervisorId,
            @RequestParam Long deadlineId, // 👈 Deadline ID catch kar rahe hain
            @RequestParam MultipartFile file) {

        Long studentId = userService.getLoggedInStudentId();
        if (studentId == null) return "redirect:/login";

        // 1. Convert string to enum
        FypDocumentType docType;
        try {
            docType = FypDocumentType.valueOf(type);
        } catch (IllegalArgumentException e) {
            docType = FypDocumentType.PROPOSAL;
        }

        // 2. Us specific deadline ko inactive (false) karein
        Deadline deadline = deadlineService.getDeadlineById(deadlineId);
        if (deadline != null) {
            deadline.setActive(false); // 👈 Submit hote hi inactive
            deadlineService.save(deadline); // Database update
        }

        // 3. Document entity banayein
        Document doc = new Document();
        doc.setTitle(title);
        doc.setType(docType);
        doc.setStudent(userService.getUserById(studentId));
        doc.setSupervisor(userService.getUserById(supervisorId));
        doc.setSubmissionDate(LocalDateTime.now());
        doc.setDeadlineDate(deadline != null ? deadline.getDueDate() : LocalDateTime.now());
        doc.setStatus("Submitted");

        // 4. File store karein
        try {
            String filePath = documentService.storeFile(file);
            doc.setFilePath(filePath);
        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/documents/upload?error=FileUploadFailed";
        }

        documentService.save(doc);
        return "redirect:/students/dashboard?success=Uploaded";
    }
}
