package com.example.demo.controller;

import com.example.demo.model.Deadline;
import com.example.demo.model.Document;
import com.example.demo.model.FypDocumentType;
import com.example.demo.repository.DeadlineRepository;
import com.example.demo.service.DeadlineService;
import com.example.demo.service.DocumentService;
import com.example.demo.service.NotificationService;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Controller
@RequestMapping("/committee")
public class CommitteeController {

    private final DocumentService documentService;
    private final UserService userService;
    private final NotificationService notificationService;

    public CommitteeController(DocumentService documentService, UserService userService, NotificationService notificationService) {
        this.documentService = documentService;
        this.userService = userService;
        this.notificationService = notificationService;
    }

    // Committee Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Document> documents = documentService.getDocumentsByStatus("APPROVED");
        model.addAttribute("documents", documents);
        return "committee-dashboard";
    }

    @PostMapping("/document/{id}/grade")
    public String gradeDocument(
            @PathVariable Long id,
            @RequestParam Integer contentQuality,
            @RequestParam Integer formattingPresentation,
            @RequestParam Integer originality,
            @RequestParam Integer timeliness,
            @RequestParam String feedback
    ) {
        // Calculate total marks
        int total = contentQuality + formattingPresentation + originality + timeliness;

        // Assign letter grade based on total percentage
        String grade;
        if (total >= 90) grade = "A";
        else if (total >= 80) grade = "B";
        else if (total >= 70) grade = "C";
        else if (total >= 60) grade = "D";
        else grade = "F";

        // Update document
        documentService.gradeDocumentRubric(id, contentQuality, formattingPresentation, originality, timeliness, grade, feedback);

        Document doc = documentService.getDocumentById(id);
        notificationService.sendNotification(
                doc.getStudent().getId(),
                "Your document '" + doc.getTitle() + "' has been graded: " + grade
        );

        return "redirect:/committee/dashboard";
    }

    // Request revision
    @PostMapping("/document/{id}/revision")
    public String requestRevision(
            @PathVariable Long id,
            @RequestParam String feedback
    ) {
        documentService.updateDocumentStatus(id, "REVISION", feedback);

        Document doc = documentService.getDocumentById(id);
        notificationService.sendNotification(
                doc.getStudent().getId(),
                "Revision required by Evaluation Committee for document '" + doc.getTitle() + "'"
        );

        return "redirect:/committee/dashboard";
    }
}
