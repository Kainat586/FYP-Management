package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Enumerated(EnumType.STRING)
    private FypDocumentType type;

    private String status;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private User student;

    @ManyToOne
    @JoinColumn(name = "supervisor_id")
    private User supervisor;

    // ✅ Rubric Fields
    private Integer contentQuality;
    private Integer formattingPresentation;
    private Integer originality;
    private Integer timeliness;
    private String feedback;

    private LocalDateTime submissionDate;
    private String grade;
    private LocalDateTime deadlineDate;

    private String filePath;

    // ---------------- Getters & Setters ----------------

    // Content Quality
    public Integer getContentQuality() {
        return contentQuality;
    }

    public void setContentQuality(Integer contentQuality) {
        this.contentQuality = contentQuality;
    }

    // Formatting & Presentation
    public Integer getFormattingPresentation() {
        return formattingPresentation;
    }

    public void setFormattingPresentation(Integer formattingPresentation) {
        this.formattingPresentation = formattingPresentation;
    }

    // Originality
    public Integer getOriginality() {
        return originality;
    }

    public void setOriginality(Integer originality) {
        this.originality = originality;
    }

    // Timeliness
    public Integer getTimeliness() {
        return timeliness;
    }

    public void setTimeliness(Integer timeliness) {
        this.timeliness = timeliness;
    }


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public FypDocumentType getType() { return type; }
    public void setType(FypDocumentType type) { this.type = type; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }

    public User getSupervisor() { return supervisor; }
    public void setSupervisor(User supervisor) { this.supervisor = supervisor; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public LocalDateTime getSubmissionDate() { return submissionDate; }
    public void setSubmissionDate(LocalDateTime submissionDate) { this.submissionDate = submissionDate; }

    public LocalDateTime getDeadlineDate() { return deadlineDate; }
    public void setDeadlineDate(LocalDateTime deadlineDate) { this.deadlineDate = deadlineDate; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
}
