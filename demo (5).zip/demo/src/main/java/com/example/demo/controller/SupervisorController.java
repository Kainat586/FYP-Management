package com.example.demo.controller;

import com.example.demo.model.Document;
import com.example.demo.model.User;
import com.example.demo.service.DocumentService;
import com.example.demo.service.NotificationService;
import com.example.demo.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/supervisors")
public class SupervisorController {

    private final UserService userService;
    private final DocumentService documentService;
    private final NotificationService notificationService;

    public SupervisorController(
            UserService userService,
            DocumentService documentService,
            NotificationService notificationService
    ) {
        this.userService = userService;
        this.documentService = documentService;
        this.notificationService = notificationService;
    }

    // ================= DASHBOARD =================
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Long supervisorId = userService.getLoggedInStudentId(); // Change this if you have getLoggedInSupervisorId()
        if (supervisorId == null) {
            return "redirect:/login";
        }

        User supervisor = userService.getUserById(supervisorId);
        model.addAttribute("supervisor", supervisor);

        List<Document> documents = documentService.getDocumentsBySupervisorId(supervisorId);
        model.addAttribute("documents", documents);

        return "supervisor-dashboard";
    }

    // ================= APPROVE =================
    @PostMapping("/document/{id}/approve")
    public String approveDocument(@PathVariable Long id) {
        documentService.updateDocumentStatus(id, "APPROVED", null);

        Document doc = documentService.getDocumentsBySupervisorId(userService.getLoggedInStudentId())
                .stream()
                .filter(d -> d.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (doc != null) {
            notificationService.sendNotification(
                    doc.getStudent().getId(),
                    "Your document '" + doc.getTitle() + "' has been APPROVED"
            );
        }

        return "redirect:/supervisors/dashboard";
    }

    // ================= REVISION =================
    @PostMapping("/document/{id}/revision")
    public String requestRevision(
            @PathVariable Long id,
            @RequestParam("feedback") String feedback) {

        // status aur feedback update
        documentService.updateDocumentStatus(id, "REVISION", feedback);

        // student ko notification bhejna
        Document doc = documentService.getDocumentsBySupervisorId(userService.getLoggedInStudentId())
                .stream()
                .filter(d -> d.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (doc != null) {
            notificationService.sendNotification(
                    doc.getStudent().getId(),
                    "Revision required for document '" + doc.getTitle() + "'"
            );
        }

        return "redirect:/supervisors/dashboard";
    }

}
