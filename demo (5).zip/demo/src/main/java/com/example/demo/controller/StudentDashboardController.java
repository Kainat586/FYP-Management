package com.example.demo.controller;

import com.example.demo.model.Deadline;
import com.example.demo.model.Document;
import com.example.demo.model.Notification;
import com.example.demo.model.User;
import com.example.demo.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/students")
public class StudentDashboardController {

    private final UserService userService;
    private final DocumentService documentService;
    private final NotificationService notificationService;
    private final DeadlineService deadlineService;

    public StudentDashboardController(
            UserService userService,
            DocumentService documentService,
            NotificationService notificationService,
            DeadlineService deadlineService
    ) {
        this.userService = userService;
        this.documentService = documentService;
        this.notificationService = notificationService;
        this.deadlineService = deadlineService;
    }
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Long studentId = userService.getLoggedInStudentId();
        if (studentId == null) return "redirect:/login";

        User student = userService.getUserById(studentId);
        model.addAttribute("student", student);

        // Sirf wahi deadlines jo is_active = 1 hain
        List<Deadline> activeDeadlines = deadlineService.getActiveDeadlines();

        LocalDateTime now = LocalDateTime.now();

        // Split into upcoming and missed
        List<Deadline> upcoming = activeDeadlines.stream()
                .filter(d -> d.getDueDate().isAfter(now))
                .toList();

        List<Deadline> missed = activeDeadlines.stream()
                .filter(d -> d.getDueDate().isBefore(now))
                .toList();

        model.addAttribute("upcomingDeadlines", upcoming);
        model.addAttribute("missedDeadlines", missed);
        model.addAttribute("documents", documentService.getDocumentsByStudentId(studentId));


        model.addAttribute("notifications", notificationService.getUnreadNotifications(studentId));
        return "student-dashboard";
    }
    @GetMapping("/mark-as-read")
    public String markAsRead(@RequestParam("id") Long notificationId) {
        notificationService.markAsRead(notificationId);
        return "redirect:/students/dashboard";
    }
}