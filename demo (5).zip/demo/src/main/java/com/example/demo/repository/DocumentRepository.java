package com.example.demo.repository;

import com.example.demo.model.Document;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DocumentRepository extends JpaRepository<Document, Long> {

    List<Document> findByStudentId(Long studentId);  // Find all documents for a given student

    List<Document> findBySupervisorId(Long supervisorId);

    List<Document> findByStatus(String status);

    List<Document> findBySupervisorIdAndStatus(Long supervisorId, String status);
}
