function toggleForm(formType) {
    const wrapper = document.querySelector('.form-wrapper');

    if (formType === 'sign-up') {
        wrapper.style.transform = 'translateX(-100%)'; // Slide Sign Up form into view
    } else if (formType === 'sign-in') {
        wrapper.style.transform = 'translateX(0)'; // Slide Sign In form back into view
    }
}
