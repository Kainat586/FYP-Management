package com.example.demo.repository;

import com.example.demo.model.Deadline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DeadlineRepository extends JpaRepository<Deadline, Long> {

    @Query("SELECT d FROM Deadline d WHERE d.isActive = true ORDER BY d.dueDate")
    List<Deadline> findByIsActiveTrueOrderByDueDateAsc();
}

