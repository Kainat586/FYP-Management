package com.example.demo.repository;

import com.example.demo.model.Document;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

// Extend JpaRepository to use standard methods like save(), findAll(), etc.
public interface DocumentRepository extends JpaRepository<Document, Long> {

    List<Document> findByStudentId(Long studentId);  // Find all documents for a given student

    List<Document> findBySupervisorId(Long supervisorId);

    // Fetch documents by status
    List<Document> findByStatus(String status);

    // You can also combine filters if needed
    List<Document> findBySupervisorIdAndStatus(Long supervisorId, String status);
}
